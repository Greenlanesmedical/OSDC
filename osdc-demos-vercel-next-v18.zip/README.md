# OSDC Demos — v5
- `/demo1` — Modern Luxe (cinematic hero, sticky panels, scroll-snap, stats, news, directory, map)
- `/demo2` — Heritage Luxe (placeholder link)

Place your final curated images here with the SAME filenames to avoid code changes:

/public/editorial-1.webp
/public/editorial-2.webp
/public/editorial-3.webp
/public/editorial-4.webp
/public/editorial-5.webp
/public/editorial-6.webp
/public/hero-heritage.jpg (and hero-heritage.webp if available)

Tip: export WebP at 1600x900 where possible for consistent crops. Keep alt text editorial.
